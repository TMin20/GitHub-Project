function setup() {
  // put setup code here
  createCanvas(500, 500);
  background(125);
}

function draw() {

	colorMode(RGB, 255, 255, 255, 255);

	fill(130, 16, 236, 50);

	triangle(100,300,150,200,200,300)

	fill(30,144,255,50);

	triangle(350,150,400,50,450,150)

	fill (124,252,0, 50);

	quad(50, 150, 50, 50, 150, 50, 150, 150);

	fill (200, 50, 0, 50);

	quad(300, 300, 300, 200, 400, 200, 400, 300);

	noFill ();

	arc(300, 300, 100, 400, 0, radians(90));

	noFill ();

	arc(100, 300, 100, 400, 0, radians(90));

	noFill ();

	arc(50, 150, 100, 700, 0, radians(90));

	noFill ();

	arc(350, 150, 100, 700, 0, radians(90));
}