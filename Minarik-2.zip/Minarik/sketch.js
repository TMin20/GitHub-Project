let mx = 0;
let my = 0;
let px = 0;
let py = 0;
let fr = 30;
let eSize = 3;
let eLoc = 10;


function setup() {

	createCanvas(500, 500);
	background(50);
	colorMode(RGB, 255, 255, 255, 1);
	frameRate(fr);
	ellipse(eLoc, eLoc, eSize, eSize);

}

function draw() {

	let fr = sqrt(3600);
	frameRate(fr);
	let mx = mouseX;
	let my = mouseY;
	let px = pmouseX;
	let py = pmouseY;
	stroke(80, 200, 75, 0.75);
	strokeWeight(25);
	line(mx, my, px, py);
	ellipse(eLoc * 40, eLoc * 40, pow(eSize, 5), pow(eSize, 5));
	fill(150,20,50);
	ellipse(eLoc * 10, eLoc * 10, pow(eSize, 5), pow(eSize, 5));
	fill(25,20,200);

}