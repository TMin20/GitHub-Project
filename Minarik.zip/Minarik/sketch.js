function setup() {
  createCanvas(128, 128);
  background(153);
}

function draw() {
	point(32, 52);
	point(85, 20);
	point(85, 75);
	point(30, 95);
	ellipse(16, 16, 40, 40);
	fill(200)
	ellipse(10, 110, 25, 25);
	strokeWeight(12.0);
	strokeCap(ROUND);
	fill(170)
	ellipse(110, 100, 50, 50);
	noStroke();
	ellipse(66, 46, 35, 35);
}